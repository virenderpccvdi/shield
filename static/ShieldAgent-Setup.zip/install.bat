@echo off
:: Shield Agent Installer for Windows
:: Run as Administrator
:: Version 1.0.0 | shield.rstglobal.in

title Shield Agent Setup

echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║     Shield Parental Control Agent — v1.0.0           ║
echo  ║     Installer  ^|  shield.rstglobal.in                ║
echo  ╚══════════════════════════════════════════════════════╝
echo.

:: Check admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] This installer must be run as Administrator.
    echo         Right-click install.bat and select "Run as administrator".
    pause
    exit /b 1
)

:: Check Python 3.8+
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.8+ is required but not found.
    echo         Please install Python from https://python.org/downloads/
    echo         Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

echo [1/5] Checking Python version...
python -c "import sys; v=sys.version_info; exit(0 if v.major==3 and v.minor>=8 else 1)"
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.8 or higher is required.
    pause
    exit /b 1
)
echo         Python OK.

:: Install to ProgramFiles
set "INSTALL_DIR=%ProgramFiles%\RSTGlobal\ShieldAgent"
echo [2/5] Installing to %INSTALL_DIR%...
mkdir "%INSTALL_DIR%" 2>nul
xcopy /E /I /Y /Q "%~dp0shield_agent" "%INSTALL_DIR%\shield_agent\" >nul
copy /Y "%~dp0main.py" "%INSTALL_DIR%\" >nul
copy /Y "%~dp0requirements.txt" "%INSTALL_DIR%\" >nul

echo [3/5] Installing Python dependencies...
python -m pip install --quiet pywin32 cryptography 2>nul
if %errorlevel% neq 0 (
    echo [WARN] pip install failed — retrying with --user
    python -m pip install --user --quiet pywin32 cryptography
)

:: Create wrapper bat to run service
echo @python "%INSTALL_DIR%\main.py" %%* > "%INSTALL_DIR%\shield-agent.bat"

:: Add to PATH via registry
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" ^
    /v "Path" /t REG_EXPAND_SZ /d "%%Path%%;%INSTALL_DIR%" /f >nul 2>&1

echo [4/5] Installing Windows service...
python "%INSTALL_DIR%\main.py" install
if %errorlevel% neq 0 (
    echo [WARN] Service install failed. You can start manually:
    echo         python "%INSTALL_DIR%\main.py" run
)

echo [5/5] Starting Shield Agent service...
python "%INSTALL_DIR%\main.py" start

echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║  Installation complete!                              ║
echo  ║                                                      ║
echo  ║  Next step — pair this PC with a child profile:     ║
echo  ║  1. Open the Shield dashboard or parent app          ║
echo  ║  2. Go to Devices → Windows PC → Generate Code      ║
echo  ║  3. Run: shield-agent pair XXXXXX                   ║
echo  ║                                                      ║
echo  ║  Dashboard: https://shield.rstglobal.in/app/        ║
echo  ╚══════════════════════════════════════════════════════╝
echo.

set /p PAIR_CODE="Enter pairing code now (or press Enter to skip): "
if not "%PAIR_CODE%"=="" (
    python "%INSTALL_DIR%\main.py" pair %PAIR_CODE%
    python "%INSTALL_DIR%\main.py" restart
)

echo.
echo Shield Agent is running. Check status:
echo   shield-agent status
echo.
pause
