@echo off
title Shield Agent Uninstaller
echo Shield Agent — Uninstaller
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Must run as Administrator.
    pause
    exit /b 1
)

set "INSTALL_DIR=%ProgramFiles%\RSTGlobal\ShieldAgent"

echo Stopping Shield Agent service...
python "%INSTALL_DIR%\main.py" stop 2>nul
python "%INSTALL_DIR%\main.py" uninstall 2>nul

echo Restoring DNS settings...
for /f "tokens=*" %%i in ('netsh interface show interface ^| findstr "Connected"') do (
    netsh interface ipv4 set dns "%%i" source=dhcp 2>nul
)

echo Removing files...
rmdir /S /Q "%INSTALL_DIR%" 2>nul

echo.
echo Shield Agent has been removed.
echo DNS settings have been restored.
pause
