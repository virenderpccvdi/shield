Shield Agent for Windows — v1.0.0
==================================
https://shield.rstglobal.in

REQUIREMENTS
------------
  Windows 10 or Windows 11 (64-bit)
  Python 3.8 or higher (https://python.org/downloads/)
  Administrator account

INSTALLATION
------------
1. Install Python 3.8+ from https://python.org/downloads/
   IMPORTANT: Check "Add Python to PATH" during installation.

2. Right-click install.bat and select "Run as administrator"

3. When asked for a pairing code:
   - Open the Shield parent app or dashboard
   - Go to Devices → Windows PC → Generate Code
   - Enter the 6-digit code

4. The Shield Agent will start automatically on every boot.

WHAT IT DOES
------------
  DNS Filtering  — Intercepts all DNS queries and filters through
                   your child's Shield profile rules.
  Tamper Proof   — Detects and reverses DNS bypass attempts.
  Reporting      — Sends activity data to the Shield dashboard.
  Screen Time    — Enforces time budgets and bedtime locks.

MANAGE
------
  shield-agent status    Check agent status and pairing
  shield-agent pair XXX  Pair with a child profile
  shield-agent stop      Stop the service
  shield-agent start     Start the service

UNINSTALL
---------
  Run uninstall.bat as Administrator, or:
  shield-agent uninstall

SUPPORT
-------
  https://shield.rstglobal.in
  support@rstglobal.in
